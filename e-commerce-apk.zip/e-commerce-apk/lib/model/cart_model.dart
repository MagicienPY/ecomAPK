import 'package:flutter/material.dart';

class Cart {
  final String? name;
  final String? image;
  final double? price;
  final int? quantity;
  final String? color;
  final String? size;
  Cart(
      {this.name,
      this.image,
      this.price,
      this.quantity,
      this.color,
      this.size});
}

import 'package:flutter/material.dart';

class CategoryIcon {
  final String? image;
  CategoryIcon({this.image});
}

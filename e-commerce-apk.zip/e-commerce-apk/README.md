# E-commerce App | Mobile

This is an E-commerce App for flutter using firebase.

## UI

<img src="screenshots/z3206519098785_956880b30c46ef768ae4c54f5fac8884.jpg" width="350" height="700">
<img src="screenshots/z3206519024671_6e5f7d332f046e032c67a089da172e30.jpg" width="350" height="700">
